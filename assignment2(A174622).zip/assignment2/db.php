<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a174622";
$password = "largeredturtle";
$dbname = "a174622";
 
?>